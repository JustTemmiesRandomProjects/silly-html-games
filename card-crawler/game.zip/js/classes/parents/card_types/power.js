import { global, ctx, inputManager } from "../../../global.js"
import { Card } from "../card.js";

export class PowerCard extends Card {
    constructor() {
        super(
            "#bae1ff"
        )
    }
}