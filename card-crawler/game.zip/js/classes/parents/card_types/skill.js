import { global, ctx, inputManager } from "../../../global.js"
import { Card } from "../card.js";

export class SkillCard extends Card {
    constructor() {
        super(
            "#baffc9"
        )
    }
}