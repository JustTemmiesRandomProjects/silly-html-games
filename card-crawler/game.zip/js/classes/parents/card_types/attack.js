import { global, ctx, inputManager } from "../../../global.js"
import { Card } from "../card.js";

export class AttackCard extends Card {
    constructor() {
        super(
            "#ffb3ba"
        )
    }
}