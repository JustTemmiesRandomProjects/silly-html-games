import { TargetSkillCard } from "../../../classes/parents/card_types/target_skill.js"

export class LegSweepCard extends TargetSkillCard {
    constructor() {
        super()

        this.name = "Beaver"
        
        this.register()
    }
}